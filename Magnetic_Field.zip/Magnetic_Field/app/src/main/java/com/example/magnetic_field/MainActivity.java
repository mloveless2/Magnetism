package com.example.magnetic_field;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Environment;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;


public class MainActivity extends AppCompatActivity implements SensorEventListener, TextToSpeech.OnInitListener {

    float[] mag = new float[3];
    private ArrayList<MagRecord> magR;
    private long timeStamp;

    private Sensor magS;
    private SensorManager manager;
    private TextToSpeech talk;

    private TextView mX, mY, mZ, debug;

    private ToggleButton toggle;
    private boolean button = false;

    private int m;
    private String fileName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initVar();
    }

    protected void onPause() {
        super.onPause();
        manager.unregisterListener(this);
    }

    protected void onDestroy() {
        if (talk != null) {
            talk.stop();
            talk.shutdown();
        }
        super.onDestroy();
    }

    protected void onResume() {
        super.onResume();

        manager.registerListener(this, magS, manager.SENSOR_DELAY_UI);
    }

    private void initVar() {
        magR = new ArrayList<MagRecord>();

        m = 0;

        talk = new TextToSpeech(this, this);

        mX = (TextView) findViewById(R.id.magX);
        mY = (TextView) findViewById(R.id.magY);
        mZ = (TextView) findViewById(R.id.magZ);
        debug = (TextView) findViewById(R.id.debug);

        toggle = (ToggleButton) findViewById(R.id.toggleButton);

        manager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        if (manager.getSensorList(Sensor.TYPE_MAGNETIC_FIELD).size() == 0) {
            debug.setText("No Magnetism Installed");
        } else {
            magS = manager.getSensorList(Sensor.TYPE_MAGNETIC_FIELD).get(0);

            if (!manager.registerListener(this, magS, SensorManager.SENSOR_DELAY_UI)) {
                debug.setText("Cant Register the magnetism sensor listener");
            }
        }

        toggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (toggle.isChecked()) {
                    button = true;


                    speech("Please remain stationary for five seconds");
                    debug.setText("Recording...");
                } else {
                    button = false;
                    speech("Recording Stopped");

                    logReadings(convertRecords());
                    magR.clear();
                }
            }
        });

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private String convertRecords() {
        StringBuilder stringRec = new StringBuilder();

        for (int x = 0; x < magR.size(); ++x) {

            stringRec.append(magR.get(x).getMagnetism(0));
            stringRec.append("," + magR.get(x).getMagnetism(1));
            stringRec.append("," + magR.get(x).getMagnetism(2));
            stringRec.append("," + magR.get(x).getTimeStamp() + "\n");

        }
        return stringRec.toString();
    }

    private void logReadings(String s) {
        try {
            File root = Environment.getExternalStorageDirectory();

            if (root.canWrite()) {
                Date date = new Date();
                Timestamp ts = new Timestamp(date.getTime());

                String dateTime = new java.text.SimpleDateFormat("dd_MM_yyyy_HH_mm_ss").format(ts);
                fileName = "sensor_log" + dateTime + ".csv";

                File gpxfile = new File(root, fileName);
                FileWriter gpxWriter = new FileWriter(gpxfile);

                BufferedWriter out = new BufferedWriter(gpxWriter);
                out.write(s);
                Toast.makeText(this, "File Saved", Toast.LENGTH_SHORT).show();
                out.close();
            } else {
                Toast.makeText(this, "Cannot Write File", Toast.LENGTH_SHORT).show();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void speech(String s) {
        talk.speak(s, TextToSpeech.QUEUE_FLUSH, null);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        Date date = new Date();

        if (sensorEvent.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
            mag = sensorEvent.values;

            mX.setText("X: " + mag[0]);
            mY.setText("Y: " + mag[1]);
            mZ.setText("Z: " + mag[2]);

            if (button && sensorEvent.sensor.equals(magS)) {
                if (timeStamp != date.getTime()) {
                    timeStamp = date.getTime();

                    magR.add(new MagRecord(timeStamp, mag));
                    m++;

                }
                switch (sensorEvent.accuracy) {
                    case SensorManager.SENSOR_STATUS_ACCURACY_HIGH:
                        debug.setText("Accuracy: High");
                        break;
                    case SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM:
                        debug.setText("Acurracy: Medium");
                        break;
                    case SensorManager.SENSOR_STATUS_ACCURACY_LOW:
                        debug.setText("Accuracy: Low");
                        break;
                    default:
                        debug.setText("Accuracy: UNAVAILABLE");
                        break;
                }
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {
    }

    @Override
    public void onInit(int i) {
        if (i == TextToSpeech.SUCCESS) {
            Toast.makeText(this, "Welcome To The Magnetism Recording", Toast.LENGTH_SHORT).show();

            int result = talk.setLanguage(Locale.US);
            if (result == TextToSpeech.LANG_NOT_SUPPORTED || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Toast.makeText(this, "Language Not Supported", Toast.LENGTH_SHORT).show();
            }

            talk.setSpeechRate(1.0f);

            speech("Welcome to the magnetism application. Press the toggle button to start recording and again to stop");
        } else {
            Toast.makeText(this, "TextToSpeech cannot be initiated", Toast.LENGTH_SHORT).show();
        }
    }
}