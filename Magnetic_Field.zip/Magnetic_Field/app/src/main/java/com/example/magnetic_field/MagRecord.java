package com.example.magnetic_field;

public class MagRecord {
    private float[] mag;
    private long timeStamp;

    public MagRecord(){
        this.mag = new float[3];
    }
    public MagRecord(long timeStamp, float[] magValues){
        this.mag = new float[3];
        this.timeStamp = new Long(timeStamp);
        this.mag = magValues.clone();
    }
    public MagRecord(long timeStamp, float x, float y, float z){
        this.mag = new float[3];
        this.timeStamp = timeStamp;
        this.mag[0] = x;
        this.mag[1] = y;
        this.mag[2] = z;
    }

    protected void setMag(float[] magValues){
        this.mag = magValues;
    }
    protected float[] getMag(){
        return this.mag;
    }
    protected float getMagnetism(int index){
        return this.mag[index];
    }
    protected void setTimeStamp(long timeStamp){
        this.timeStamp = timeStamp;
    }
    protected long getTimeStamp(){
        return this.timeStamp;
    }
}
